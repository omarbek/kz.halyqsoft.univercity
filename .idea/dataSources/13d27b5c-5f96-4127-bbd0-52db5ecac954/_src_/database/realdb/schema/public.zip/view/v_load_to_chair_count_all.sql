CREATE VIEW v_load_to_chair_count_all AS SELECT v_load_to_chair_count.curriculum_id,
    sum(v_load_to_chair_count.lc_count) AS lc_count,
    sum(v_load_to_chair_count.pr_count) AS pr_count,
    sum(v_load_to_chair_count.lb_count) AS lb_count,
    sum(v_load_to_chair_count.with_teacher_count) AS with_teacher_count,
    sum(v_load_to_chair_count.rating_count) AS rating_count,
    sum(v_load_to_chair_count.exam_count) AS exam_count,
    sum(v_load_to_chair_count.control_count) AS control_count,
    sum(v_load_to_chair_count.course_work_count) AS course_work_count,
    sum(v_load_to_chair_count.diploma_count) AS diploma_count,
    sum(v_load_to_chair_count.practice_count) AS practice_count,
    sum(v_load_to_chair_count.mek) AS mek,
    sum(v_load_to_chair_count.protect_diploma_count) AS protect_diploma_count,
    sum(v_load_to_chair_count.total_count) AS total_count
   FROM v_load_to_chair_count
  GROUP BY v_load_to_chair_count.curriculum_id;
