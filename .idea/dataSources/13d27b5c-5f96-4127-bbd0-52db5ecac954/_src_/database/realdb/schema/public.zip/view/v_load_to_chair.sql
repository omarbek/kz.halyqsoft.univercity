CREATE VIEW v_load_to_chair AS SELECT DISTINCT nextval('s_v_load_to_chair'::regclass) AS id,
    subj.id AS subject_id,
    curr.id AS curriculum_id,
    curr_subj.subject_name,
        CASE
            WHEN (curr_subj.semester_id = ANY (ARRAY[(1)::bigint, (2)::bigint])) THEN 1
            WHEN (curr_subj.semester_id = ANY (ARRAY[(3)::bigint, (4)::bigint])) THEN 2
            WHEN (curr_subj.semester_id = ANY (ARRAY[(5)::bigint, (6)::bigint])) THEN 3
            WHEN (curr_subj.semester_id = ANY (ARRAY[(7)::bigint, (8)::bigint])) THEN 4
            ELSE NULL::integer
        END AS study_year,
    string_agg((gr.group_name)::text, ', '::text) AS stream,
    sem.semester_name,
    sum(gr.student_count) AS student_number,
    curr_subj.credit,
    subj.lc_count,
    (subj.pr_count * (count(gr.student_count))::numeric) AS pr_count,
    (subj.lb_count * (count(gr.student_count))::numeric) AS lb_count,
    (curr_subj.credit * (5)::numeric) AS with_teacher_count,
    (sum(gr.student_count) / (4)::numeric) AS rating_count,
    (count(gr.student_count) * 2) AS exam_count,
        CASE
            WHEN (curr.student_diploma_type_id = 1) THEN (0)::numeric
            ELSE (sum(gr.student_count) / (5)::numeric)
        END AS control_count,
        CASE
            WHEN (subj.course_work = true) THEN (sum(gr.student_count) / (4)::numeric)
            ELSE (0)::numeric
        END AS course_work_count,
        CASE
            WHEN (curr_subj.semester_id = ANY (ARRAY[(7)::bigint, (8)::bigint])) THEN ((12)::numeric * sum(gr.student_count))
            ELSE (0)::numeric
        END AS diploma_count,
        CASE
            WHEN (subj.week_number IS NOT NULL) THEN (subj.week_number * sum(gr.student_count))
            ELSE (0)::numeric
        END AS practice_count,
        CASE
            WHEN (curr_subj.semester_id = 8) THEN (sum(gr.student_count) / (2)::numeric)
            ELSE (0)::numeric
        END AS mek,
        CASE
            WHEN (curr_subj.semester_id = 8) THEN (sum(gr.student_count) * 0.6)
            ELSE (0)::numeric
        END AS protect_diploma_count,
    (((((((((((subj.lc_count + subj.pr_count) + subj.lb_count) + subj.with_teacher_count) + (sum(gr.student_count) / (4)::numeric)) + ((count(gr.student_count) * 2))::numeric) +
        CASE
            WHEN (curr.student_diploma_type_id = 1) THEN (0)::numeric
            ELSE (sum(gr.student_count) / (5)::numeric)
        END) +
        CASE
            WHEN (subj.course_work = true) THEN (sum(gr.student_count) / (4)::numeric)
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (curr_subj.semester_id = ANY (ARRAY[(7)::bigint, (8)::bigint])) THEN ((12)::numeric * sum(gr.student_count))
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (subj.week_number IS NOT NULL) THEN (subj.week_number * sum(gr.student_count))
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (curr_subj.semester_id = 8) THEN (sum(gr.student_count) / (2)::numeric)
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (curr_subj.semester_id = 8) THEN (sum(gr.student_count) * 0.6)
            ELSE (0)::numeric
        END) AS total_count
   FROM (((((v_curriculum_subject curr_subj
     JOIN subject subj ON ((subj.id = curr_subj.subject_id)))
     JOIN curriculum curr ON ((curr_subj.curriculum_id = curr.id)))
     JOIN v_group gr ON ((gr.speciality_id = curr.speciality_id)))
     JOIN stream_group str_gr ON ((str_gr.group_id = gr.id)))
     JOIN semester sem ON ((sem.id = curr_subj.semester_id)))
  WHERE (((curr_subj.deleted = false) AND (subj.deleted = false)) AND (curr.deleted = false))
  GROUP BY curr_subj.subject_name, curr_subj.semester_id, sem.semester_name, curr_subj.credit, subj.lc_count, subj.pr_count, subj.lb_count, subj.course_work, subj.week_number, curr_subj.id, subj.id, curr.id
UNION ALL
 SELECT DISTINCT nextval('s_v_load_to_chair'::regclass) AS id,
    subj.id AS subject_id,
    curr.id AS curriculum_id,
    curr_add_pr.subject_name_ru AS subject_name,
        CASE
            WHEN (curr_add_pr.semester_id = ANY (ARRAY[(1)::bigint, (2)::bigint])) THEN 1
            WHEN (curr_add_pr.semester_id = ANY (ARRAY[(3)::bigint, (4)::bigint])) THEN 2
            WHEN (curr_add_pr.semester_id = ANY (ARRAY[(5)::bigint, (6)::bigint])) THEN 3
            WHEN (curr_add_pr.semester_id = ANY (ARRAY[(7)::bigint, (8)::bigint])) THEN 4
            ELSE NULL::integer
        END AS study_year,
    string_agg((gr.group_name)::text, ', '::text) AS stream,
    sem.semester_name,
    sum(gr.student_count) AS student_number,
    curr_add_pr.credit,
    subj.lc_count,
    (subj.pr_count * (count(gr.student_count))::numeric) AS pr_count,
    (subj.lb_count * (count(gr.student_count))::numeric) AS lb_count,
    (curr_add_pr.credit * (5)::numeric) AS with_teacher_count,
    (sum(gr.student_count) / (4)::numeric) AS rating_count,
    (count(gr.student_count) * 2) AS exam_count,
        CASE
            WHEN (curr.student_diploma_type_id = 1) THEN (0)::numeric
            ELSE (sum(gr.student_count) / (5)::numeric)
        END AS control_count,
        CASE
            WHEN (subj.course_work = true) THEN (sum(gr.student_count) / (4)::numeric)
            ELSE (0)::numeric
        END AS course_work_count,
        CASE
            WHEN (curr_add_pr.semester_id = ANY (ARRAY[(7)::bigint, (8)::bigint])) THEN ((12)::numeric * sum(gr.student_count))
            ELSE (0)::numeric
        END AS diploma_count,
        CASE
            WHEN (subj.week_number IS NOT NULL) THEN (subj.week_number * sum(gr.student_count))
            ELSE (0)::numeric
        END AS practice_count,
        CASE
            WHEN (curr_add_pr.semester_id = 8) THEN (sum(gr.student_count) / (2)::numeric)
            ELSE (0)::numeric
        END AS mek,
        CASE
            WHEN (curr_add_pr.semester_id = 8) THEN (sum(gr.student_count) * 0.6)
            ELSE (0)::numeric
        END AS protect_diploma_count,
    (((((((((((subj.lc_count + subj.pr_count) + subj.lb_count) + subj.with_teacher_count) + (sum(gr.student_count) / (4)::numeric)) + ((count(gr.student_count) * 2))::numeric) +
        CASE
            WHEN (curr.student_diploma_type_id = 1) THEN (0)::numeric
            ELSE (sum(gr.student_count) / (5)::numeric)
        END) +
        CASE
            WHEN (subj.course_work = true) THEN (sum(gr.student_count) / (4)::numeric)
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (curr_add_pr.semester_id = ANY (ARRAY[(7)::bigint, (8)::bigint])) THEN ((12)::numeric * sum(gr.student_count))
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (subj.week_number IS NOT NULL) THEN (subj.week_number * sum(gr.student_count))
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (curr_add_pr.semester_id = 8) THEN (sum(gr.student_count) / (2)::numeric)
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (curr_add_pr.semester_id = 8) THEN (sum(gr.student_count) * 0.6)
            ELSE (0)::numeric
        END) AS total_count
   FROM (((((v_curriculum_add_program curr_add_pr
     JOIN subject subj ON ((subj.id = curr_add_pr.subject_id)))
     JOIN curriculum curr ON ((curr_add_pr.curriculum_id = curr.id)))
     JOIN v_group gr ON ((gr.speciality_id = curr.speciality_id)))
     JOIN stream_group str_gr ON ((str_gr.group_id = gr.id)))
     JOIN semester sem ON ((sem.id = curr_add_pr.semester_id)))
  WHERE (((curr_add_pr.deleted = false) AND (subj.deleted = false)) AND (curr.deleted = false))
  GROUP BY curr_add_pr.subject_name_ru, curr_add_pr.semester_id, sem.semester_name, curr_add_pr.credit, subj.lc_count, subj.pr_count, subj.lb_count, subj.course_work, subj.week_number, curr_add_pr.id, subj.id, curr.id
UNION ALL
 SELECT DISTINCT nextval('s_v_load_to_chair'::regclass) AS id,
    subj.id AS subject_id,
    curr.id AS curriculum_id,
    curr_after_sem.subject_name_ru AS subject_name,
        CASE
            WHEN (curr_after_sem.semester_id = ANY (ARRAY[(1)::bigint, (2)::bigint])) THEN 1
            WHEN (curr_after_sem.semester_id = ANY (ARRAY[(3)::bigint, (4)::bigint])) THEN 2
            WHEN (curr_after_sem.semester_id = ANY (ARRAY[(5)::bigint, (6)::bigint])) THEN 3
            WHEN (curr_after_sem.semester_id = ANY (ARRAY[(7)::bigint, (8)::bigint])) THEN 4
            ELSE NULL::integer
        END AS study_year,
    string_agg((gr.group_name)::text, ', '::text) AS stream,
    sem.semester_name,
    sum(gr.student_count) AS student_number,
    curr_after_sem.credit,
    subj.lc_count,
    (subj.pr_count * (count(gr.student_count))::numeric) AS pr_count,
    (subj.lb_count * (count(gr.student_count))::numeric) AS lb_count,
    (curr_after_sem.credit * (5)::numeric) AS with_teacher_count,
    (sum(gr.student_count) / (4)::numeric) AS rating_count,
    (count(gr.student_count) * 2) AS exam_count,
        CASE
            WHEN (curr.student_diploma_type_id = 1) THEN (0)::numeric
            ELSE (sum(gr.student_count) / (5)::numeric)
        END AS control_count,
        CASE
            WHEN (subj.course_work = true) THEN (sum(gr.student_count) / (4)::numeric)
            ELSE (0)::numeric
        END AS course_work_count,
        CASE
            WHEN (curr_after_sem.semester_id = ANY (ARRAY[(7)::bigint, (8)::bigint])) THEN ((12)::numeric * sum(gr.student_count))
            ELSE (0)::numeric
        END AS diploma_count,
        CASE
            WHEN (subj.week_number IS NOT NULL) THEN (subj.week_number * sum(gr.student_count))
            ELSE (0)::numeric
        END AS practice_count,
        CASE
            WHEN (curr_after_sem.semester_id = 8) THEN (sum(gr.student_count) / (2)::numeric)
            ELSE (0)::numeric
        END AS mek,
        CASE
            WHEN (curr_after_sem.semester_id = 8) THEN (sum(gr.student_count) * 0.6)
            ELSE (0)::numeric
        END AS protect_diploma_count,
    (((((((((((subj.lc_count + subj.pr_count) + subj.lb_count) + subj.with_teacher_count) + (sum(gr.student_count) / (4)::numeric)) + ((count(gr.student_count) * 2))::numeric) +
        CASE
            WHEN (curr.student_diploma_type_id = 1) THEN (0)::numeric
            ELSE (sum(gr.student_count) / (5)::numeric)
        END) +
        CASE
            WHEN (subj.course_work = true) THEN (sum(gr.student_count) / (4)::numeric)
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (curr_after_sem.semester_id = ANY (ARRAY[(7)::bigint, (8)::bigint])) THEN ((12)::numeric * sum(gr.student_count))
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (subj.week_number IS NOT NULL) THEN (subj.week_number * sum(gr.student_count))
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (curr_after_sem.semester_id = 8) THEN (sum(gr.student_count) / (2)::numeric)
            ELSE (0)::numeric
        END) +
        CASE
            WHEN (curr_after_sem.semester_id = 8) THEN (sum(gr.student_count) * 0.6)
            ELSE (0)::numeric
        END) AS total_count
   FROM (((((v_curriculum_after_semester curr_after_sem
     JOIN subject subj ON ((subj.id = curr_after_sem.subject_id)))
     JOIN curriculum curr ON ((curr_after_sem.curriculum_id = curr.id)))
     JOIN v_group gr ON ((gr.speciality_id = curr.speciality_id)))
     JOIN stream_group str_gr ON ((str_gr.group_id = gr.id)))
     JOIN semester sem ON ((sem.id = curr_after_sem.semester_id)))
  WHERE (((curr_after_sem.deleted = false) AND (subj.deleted = false)) AND (curr.deleted = false))
  GROUP BY curr_after_sem.subject_name_ru, curr_after_sem.semester_id, sem.semester_name, curr_after_sem.credit, subj.lc_count, subj.pr_count, subj.lb_count, subj.course_work, subj.week_number, curr_after_sem.id, subj.id, curr.id
  ORDER BY 7;
