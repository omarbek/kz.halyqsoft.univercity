CREATE VIEW v_stream AS SELECT str.id,
    str.name AS stream_name,
    str.semester_data_id,
    str.semester_id,
    sum(gr.student_count) AS student_count
   FROM ((stream str
     JOIN stream_group str_gr ON ((str_gr.stream_id = str.id)))
     JOIN v_group gr ON ((gr.id = str_gr.group_id)))
  GROUP BY str.id;
