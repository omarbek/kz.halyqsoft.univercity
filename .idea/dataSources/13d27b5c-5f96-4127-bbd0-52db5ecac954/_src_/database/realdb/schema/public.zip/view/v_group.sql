CREATE VIEW v_group AS SELECT gr.id,
    gr.speciality_id,
    gr.name AS group_name,
    gr.language_id,
    gr.study_year_id,
    count(1) AS student_count
   FROM (groups gr
     JOIN v_student stu ON ((stu.groups_id = gr.id)))
  WHERE ((stu.category_id = 3) AND (gr.deleted = false))
  GROUP BY gr.id;
