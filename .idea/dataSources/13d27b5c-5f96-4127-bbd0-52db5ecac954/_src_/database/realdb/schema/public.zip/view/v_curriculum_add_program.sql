CREATE VIEW v_curriculum_add_program AS SELECT curr_add_pr.id,
    curr_add_pr.curriculum_id,
    curr_add_pr.subject_id,
    subj.name_ru AS subject_name_ru,
    curr_add_pr.code AS subject_code,
    subj.creditability_id,
    cred.credit,
    curr_add_pr.semester_id,
    sem.semester_name,
    edu_mod_type.id AS education_module_type_id,
    edu_mod_type.type_name AS education_module_type_name,
    curr_add_pr.deleted
   FROM ((((curriculum_add_program curr_add_pr
     JOIN subject subj ON ((curr_add_pr.subject_id = subj.id)))
     JOIN creditability cred ON ((subj.creditability_id = cred.id)))
     JOIN semester sem ON ((curr_add_pr.semester_id = sem.id)))
     JOIN education_module_type edu_mod_type ON ((edu_mod_type.id = curr_add_pr.education_module_type_id)));
