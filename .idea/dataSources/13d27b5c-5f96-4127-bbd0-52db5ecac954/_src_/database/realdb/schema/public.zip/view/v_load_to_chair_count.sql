CREATE VIEW v_load_to_chair_count AS SELECT v_load_to_chair.study_year,
    v_load_to_chair.curriculum_id,
    sum(v_load_to_chair.lc_count) AS lc_count,
    sum(v_load_to_chair.pr_count) AS pr_count,
    sum(v_load_to_chair.lb_count) AS lb_count,
    sum(v_load_to_chair.with_teacher_count) AS with_teacher_count,
    sum(v_load_to_chair.rating_count) AS rating_count,
    sum(v_load_to_chair.exam_count) AS exam_count,
    sum(v_load_to_chair.control_count) AS control_count,
    sum(v_load_to_chair.course_work_count) AS course_work_count,
    sum(v_load_to_chair.diploma_count) AS diploma_count,
    sum(v_load_to_chair.practice_count) AS practice_count,
    sum(v_load_to_chair.mek) AS mek,
    sum(v_load_to_chair.protect_diploma_count) AS protect_diploma_count,
    sum(v_load_to_chair.total_count) AS total_count
   FROM v_load_to_chair
  GROUP BY v_load_to_chair.study_year, v_load_to_chair.curriculum_id;
