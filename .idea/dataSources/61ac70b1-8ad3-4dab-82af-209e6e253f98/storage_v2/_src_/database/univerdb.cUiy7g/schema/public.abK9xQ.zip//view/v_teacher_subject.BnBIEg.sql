CREATE VIEW v_teacher_subject AS
  SELECT teacher_subject.id,
    teacher_subject.employee_id,
    subj.name_ru AS subject_name,
    subj.code AS subject_code,
    teacher_subject.group_lec_count,
    gr_size_lec.size AS group_lec_size,
    teacher_subject.group_lab_count,
    gr_size_lab.size AS group_lab_size,
    teacher_subject.group_prac_count,
    gr_size_pr.size AS group_prac_size,
    teacher_subject.fall,
    teacher_subject.spring,
    teacher_subject.summer,
    teacher_subject.load_per_hours
   FROM ((((teacher_subject teacher_subject
     JOIN subject subj ON ((teacher_subject.subject_id = subj.id)))
     LEFT JOIN group_size_lecture gr_size_lec ON ((teacher_subject.group_lec_id = gr_size_lec.id)))
     LEFT JOIN group_size_lab gr_size_lab ON ((teacher_subject.group_lab_id = gr_size_lab.id)))
     LEFT JOIN group_size_prac gr_size_pr ON ((teacher_subject.group_prac_id = gr_size_pr.id)));

