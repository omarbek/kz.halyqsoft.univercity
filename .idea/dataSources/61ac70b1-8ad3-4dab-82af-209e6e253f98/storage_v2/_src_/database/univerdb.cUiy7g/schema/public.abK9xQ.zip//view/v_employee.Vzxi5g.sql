CREATE VIEW v_employee AS
  SELECT a.id,
    b.first_name,
    b.last_name,
    b.middle_name,
    b.first_name_en,
    b.last_name_en,
    b.middle_name_en,
    b.birth_date,
    b.sex_id,
    c.sex_name,
    b.marital_status_id,
    d.status_name AS marital_status_name,
    b.nationality_id,
    e.nation_name,
    b.citizenship_id,
    f.country_name AS citizenship_name,
    b.code,
    b.login,
    b.email,
    b.phone_mobile,
    h.employee_type_id,
    i.type_name AS employee_type_name,
    h.dept_id,
    j.dept_name,
    j.dept_short_name,
    j.code AS dept_code,
    h.post_id,
    k.post_name,
    h.live_load,
    h.hire_date,
    h.dismiss_date,
    h.adviser,
    a.employee_status_id,
    g.status_name AS employee_status_name,
    b.deleted,
    b.created,
    b.updated
   FROM ((((((((((employee a
     JOIN users b ON ((a.id = b.id)))
     JOIN sex c ON ((b.sex_id = c.id)))
     JOIN marital_status d ON ((b.marital_status_id = d.id)))
     LEFT JOIN nationality e ON ((b.nationality_id = e.id)))
     JOIN country f ON ((b.citizenship_id = f.id)))
     JOIN employee_status g ON (((a.employee_status_id = g.id) AND (g.id <> 4))))
     LEFT JOIN employee_dept h ON (((h.employee_id = a.id) AND (h.dismiss_date IS NULL))))
     LEFT JOIN employee_type i ON ((h.employee_type_id = i.id)))
     LEFT JOIN department j ON ((h.dept_id = j.id)))
     LEFT JOIN post k ON ((h.post_id = k.id)))
  WHERE (b.id <> ALL (ARRAY[(1)::bigint, (2)::bigint]));

