CREATE VIEW v_employee_dept AS
  SELECT empl_dept.id,
    empl_dept.employee_id,
    empl_dept.employee_type_id,
    empl_type.type_name AS employee_type_name,
    empl_dept.dept_id,
    dep.dept_name,
    dep.dept_short_name,
    empl_dept.post_id,
    post.post_name,
    empl_dept.live_load,
    empl_dept.wage_rate,
    empl_dept.rate_load,
    empl_dept.hour_count,
    empl_dept.hire_date,
    empl_dept.dismiss_date,
    empl_dept.adviser,
    empl_dept.parent_id
   FROM ((((employee_dept empl_dept
     JOIN employee_type empl_type ON ((empl_dept.employee_type_id = empl_type.id)))
     JOIN department dep ON ((empl_dept.dept_id = dep.id)))
     LEFT JOIN post post ON ((empl_dept.post_id = post.id)))
     JOIN employee empl ON ((empl_dept.employee_id = empl.id)));

