CREATE VIEW v_entrant_speciality AS SELECT entrant_spec.id,
    entrant_spec.student_id,
    entrant_spec.university_id,
    univer.university_name,
    entrant_spec.speciality_id,
    spec.spec_name AS speciality_name,
    entrant_spec.language_id,
    lang.lang_name AS language_name
   FROM (((entrant_speciality entrant_spec
     JOIN university univer ON ((entrant_spec.university_id = univer.id)))
     JOIN speciality spec ON ((entrant_spec.speciality_id = spec.id)))
     JOIN language lang ON ((entrant_spec.language_id = lang.id)));
