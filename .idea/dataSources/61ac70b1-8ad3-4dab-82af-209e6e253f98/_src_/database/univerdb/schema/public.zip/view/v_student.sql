CREATE VIEW v_student AS SELECT stu.id,
    usr.first_name,
    usr.last_name,
    usr.middle_name,
    usr.first_name_en,
    usr.last_name_en,
    usr.middle_name_en,
    usr.birth_date,
    usr.sex_id,
    c.sex_name,
    usr.marital_status_id,
    d.status_name AS marital_status_name,
    usr.nationality_id,
    e.nation_name,
    usr.citizenship_id,
    f.country_name AS citizenship_name,
    usr.code AS user_code,
    usr.login,
    usr.email,
    usr.phone_mobile,
    stu.level_id,
    g.level_name,
    stu.category_id,
    h.category_name,
    stu.academic_status_id,
    i.status_name AS academic_status_name,
    stu.need_dorm,
    stu.entrance_year_id,
    j.entrance_year,
    j.begin_year AS entrance_begin_year,
    j.end_year AS entrance_end_year,
    k.faculty_id,
    l.dept_name AS faculty_name,
    l.dept_short_name AS faculty_short_name,
    l.code AS faculty_code,
    k.chair_id,
    m.dept_name AS chair_name,
    m.dept_short_name AS chair_short_name,
    m.code AS chair_code,
    k.speciality_id,
    (((n.code)::text || ' - '::text) || (n.spec_name)::text) AS speciality_name,
    n.code AS speciality_code,
    k.study_year_id,
    k.education_type_id,
    o.type_name AS education_type_name,
    k.entry_date,
    k.end_date,
    k.student_status_id,
    p.status_name AS student_status_name,
    usr.deleted,
    usr.created,
    usr.updated
   FROM (((((((((((((((student stu
     JOIN users usr ON ((stu.id = usr.id)))
     JOIN sex c ON ((usr.sex_id = c.id)))
     JOIN marital_status d ON ((usr.marital_status_id = d.id)))
     JOIN nationality e ON ((usr.nationality_id = e.id)))
     JOIN country f ON ((usr.citizenship_id = f.id)))
     JOIN level g ON ((stu.level_id = g.id)))
     JOIN student_category h ON ((stu.category_id = h.id)))
     LEFT JOIN academic_status i ON ((stu.academic_status_id = i.id)))
     JOIN entrance_year j ON ((stu.entrance_year_id = j.id)))
     JOIN student_education k ON (((k.student_id = stu.id) AND (k.child_id IS NULL))))
     JOIN department l ON ((k.faculty_id = l.id)))
     JOIN department m ON ((k.chair_id = m.id)))
     JOIN speciality n ON ((k.speciality_id = n.id)))
     JOIN student_education_type o ON ((k.education_type_id = o.id)))
     JOIN student_status p ON ((k.student_status_id = p.id)));
