CREATE VIEW v_curriculum_detail AS SELECT a.id,
    a.curriculum_id,
    a.semester_id,
    b.semester_name,
    a.subject_id,
    c.code AS subject_code,
    c.name_ru AS subject_name,
        CASE
            WHEN (c.subject_cycle_id = 4) THEN a.subject_cycle_id
            ELSE c.subject_cycle_id
        END AS subject_cycle_id,
        CASE
            WHEN (c.subject_cycle_id = 4) THEN i.cycle_short_name
            ELSE d.cycle_short_name
        END AS cycle_short_name,
    c.creditability_id,
    e.credit,
    c.academic_formula_id,
    f.formula,
    a.recommended_semester,
    a.consider_credit,
    c.control_type_id,
    h.type_name AS control_type_name,
    a.deleted,
    false AS elective
   FROM (((((((curriculum_detail a
     JOIN semester b ON ((a.semester_id = b.id)))
     JOIN subject c ON ((a.subject_id = c.id)))
     JOIN subject_cycle d ON ((c.subject_cycle_id = d.id)))
     JOIN creditability e ON ((c.creditability_id = e.id)))
     JOIN academic_formula f ON ((c.academic_formula_id = f.id)))
     JOIN control_type h ON ((c.control_type_id = h.id)))
     LEFT JOIN subject_cycle i ON ((a.subject_cycle_id = i.id)))
UNION ALL
 SELECT aa.id,
    aa.curriculum_id,
    aa.semester_id,
    bb.semester_name,
    aa.elective_subject_id AS subject_id,
    NULL::character varying AS subject_code,
    cc.name_ru AS subject_name,
    aa.elective_subject_cycle_id AS subject_cycle_id,
    dd.cycle_short_name,
    NULL::bigint AS creditability_id,
    aa.elective_subject_credit AS credit,
    NULL::bigint AS academic_formula_id,
    NULL::character varying AS formula,
    NULL::character varying AS recommended_semester,
    aa.consider_credit,
    NULL::bigint AS control_type_id,
    NULL::character varying AS control_type_name,
    aa.deleted,
    true AS elective
   FROM (((curriculum_detail aa
     JOIN semester bb ON ((aa.semester_id = bb.id)))
     JOIN elective_subject_label cc ON ((aa.elective_subject_id = cc.id)))
     JOIN subject_cycle dd ON ((aa.elective_subject_cycle_id = dd.id)));
