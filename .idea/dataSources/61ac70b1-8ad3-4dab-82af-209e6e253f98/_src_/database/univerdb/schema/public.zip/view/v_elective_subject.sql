CREATE VIEW v_elective_subject AS SELECT a.id,
    a.curriculum_id,
    a.semester_id,
    d.semester_name,
    a.subject_id,
    c.code AS subject_code,
    c.name_ru AS subject_name,
        CASE
            WHEN (c.subject_cycle_id = 4) THEN a.subject_cycle_id
            ELSE c.subject_cycle_id
        END AS subject_cycle_id,
        CASE
            WHEN (c.subject_cycle_id = 4) THEN i.cycle_short_name
            ELSE g.cycle_short_name
        END AS cycle_short_name,
    c.creditability_id,
    f.credit,
    c.academic_formula_id,
    e.formula,
    c.control_type_id,
    h.type_name AS control_type_name,
    a.deleted
   FROM ((((((((elective_subject a
     JOIN curriculum b ON ((b.id = a.curriculum_id)))
     JOIN subject c ON ((c.id = a.subject_id)))
     JOIN semester d ON ((d.id = a.semester_id)))
     JOIN academic_formula e ON ((c.academic_formula_id = e.id)))
     JOIN creditability f ON ((c.creditability_id = f.id)))
     JOIN subject_cycle g ON ((c.subject_cycle_id = g.id)))
     JOIN control_type h ON ((c.control_type_id = h.id)))
     LEFT JOIN subject_cycle i ON ((a.subject_cycle_id = i.id)));
