CREATE VIEW v_room_subject AS SELECT room_subj.id,
    room_subj.room_id,
    room_subj.subject_id,
    subj.name_ru AS subject_name_ru,
    subj.code AS subject_code,
    dept.dept_name AS chair_name,
    lvl.level_name,
    cred.credit,
    control_type.type_name AS control_type_name
   FROM (((((room_subject room_subj
     JOIN subject subj ON ((room_subj.subject_id = subj.id)))
     JOIN department dept ON ((subj.chair_id = dept.id)))
     JOIN level lvl ON ((subj.level_id = lvl.id)))
     JOIN creditability cred ON ((subj.creditability_id = cred.id)))
     JOIN control_type control_type ON ((subj.control_type_id = control_type.id)));
