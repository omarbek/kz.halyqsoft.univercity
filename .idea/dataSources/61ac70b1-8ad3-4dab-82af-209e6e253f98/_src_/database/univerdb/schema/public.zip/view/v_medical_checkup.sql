CREATE VIEW v_medical_checkup AS SELECT med_checkup.id,
    usr_doc.user_id,
    usr_doc.document_no,
    usr_doc.issue_date,
    usr_doc.expire_date,
    med_checkup.checkup_type_id,
    med_checkup_type.type_name AS checkup_type_name,
    med_checkup.issuer_name,
    med_checkup.allow_dorm,
    med_checkup.allow_study,
    med_checkup.allow_work,
    usr_doc.deleted
   FROM ((medical_checkup med_checkup
     JOIN user_document usr_doc ON ((med_checkup.id = usr_doc.id)))
     JOIN medical_checkup_type med_checkup_type ON ((med_checkup.checkup_type_id = med_checkup_type.id)));
