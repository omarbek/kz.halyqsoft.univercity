CREATE VIEW v_employee_degree AS SELECT empl_degree.id,
    usr_doc.user_id AS employee_id,
    usr_doc.document_no,
    usr_doc.issue_date,
    usr_doc.expire_date,
    empl_degree.degree_id,
    degree.degree_name,
    empl_degree.school_name,
    empl_degree.dissertation_topic,
    usr_doc.deleted
   FROM ((employee_degree empl_degree
     JOIN user_document usr_doc ON ((empl_degree.id = usr_doc.id)))
     JOIN degree degree ON ((empl_degree.degree_id = degree.id)));
