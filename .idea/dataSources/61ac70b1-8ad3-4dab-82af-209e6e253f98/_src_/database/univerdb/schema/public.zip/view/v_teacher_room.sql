CREATE VIEW v_teacher_room AS SELECT teacher_room.id,
    teacher_room.teacher_id,
    corpus.corpus_name,
    room.room_no,
    room_type.type_name AS room_type_name,
    room.capacity,
    room.equipment,
    room.descr
   FROM (((teacher_room teacher_room
     JOIN room room ON ((teacher_room.room_id = room.id)))
     JOIN corpus corpus ON ((room.corpus_id = corpus.id)))
     JOIN room_type room_type ON ((room.room_type_id = room_type.id)));
