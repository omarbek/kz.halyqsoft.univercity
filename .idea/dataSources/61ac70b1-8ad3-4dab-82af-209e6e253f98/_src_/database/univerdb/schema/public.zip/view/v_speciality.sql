CREATE VIEW v_speciality AS SELECT spec.id,
    spec.spec_name,
    spec.code,
    spec.chair_id,
    dep.dept_name AS chair_name,
    dep.dept_short_name AS chair_short_name,
    spec.level_id,
    lvl.level_name,
    spec.deleted
   FROM ((speciality spec
     JOIN department dep ON ((spec.chair_id = dep.id)))
     JOIN level lvl ON ((spec.level_id = lvl.id)));
