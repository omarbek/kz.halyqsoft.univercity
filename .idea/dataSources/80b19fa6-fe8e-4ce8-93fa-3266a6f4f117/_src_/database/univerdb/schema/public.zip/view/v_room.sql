CREATE VIEW v_room AS SELECT room.id,
    room.corpus_id,
    corpus.corpus_name,
    room.room_no,
    room.room_type_id,
    room_type.type_name AS room_type_name,
    room.capacity,
    room.equipment,
    room.resp_emp_id,
    btrim((((((usr.last_name)::text || ' '::text) || (usr.first_name)::text) || ' '::text) || (COALESCE(usr.middle_name, ''::character varying))::text)) AS resp_emp_fio,
    room.descr,
    room.deleted,
    room.created,
    room.updated
   FROM (((room room
     JOIN corpus corpus ON ((room.corpus_id = corpus.id)))
     JOIN room_type room_type ON ((room.room_type_id = room_type.id)))
     LEFT JOIN users usr ON ((room.resp_emp_id = usr.id)));
