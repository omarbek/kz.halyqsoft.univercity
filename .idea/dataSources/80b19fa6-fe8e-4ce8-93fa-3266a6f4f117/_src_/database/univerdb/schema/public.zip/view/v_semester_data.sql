CREATE VIEW v_semester_data AS SELECT sem_data.id,
    sem_data.year_id,
    year.entrance_year,
    sem_data.semester_period_id,
    sem_period.period_name,
    sem_data.begin_date,
    sem_data.end_date
   FROM ((semester_data sem_data
     JOIN entrance_year year ON ((sem_data.year_id = year.id)))
     JOIN semester_period sem_period ON ((sem_data.semester_period_id = sem_period.id)));
