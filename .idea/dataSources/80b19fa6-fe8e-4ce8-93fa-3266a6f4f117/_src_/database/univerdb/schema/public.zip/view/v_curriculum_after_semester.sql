CREATE VIEW v_curriculum_after_semester AS SELECT curr_after_sem.id,
    curr_after_sem.curriculum_id,
    curr_after_sem.subject_id,
    subj.name_ru AS subject_name_ru,
    curr_after_sem.code AS subject_code,
    subj.creditability_id,
    cred.credit,
    curr_after_sem.semester_id,
    sem.semester_name,
    edu_mod_type.id AS education_module_type_id,
    edu_mod_type.type_name AS education_module_type_name,
    curr_after_sem.deleted
   FROM ((((curriculum_after_semester curr_after_sem
     JOIN subject subj ON ((curr_after_sem.subject_id = subj.id)))
     JOIN creditability cred ON ((subj.creditability_id = cred.id)))
     JOIN semester sem ON ((curr_after_sem.semester_id = sem.id)))
     JOIN education_module_type edu_mod_type ON ((edu_mod_type.id = curr_after_sem.education_module_type_id)));
