create view v_room_equipment as
  SELECT room_equip.id,
    room_equip.room_id,
    room_equip.equipment_id,
    equip.equipment_name
   FROM (room_equipment room_equip
     JOIN equipment equip ON ((room_equip.equipment_id = equip.id)));

