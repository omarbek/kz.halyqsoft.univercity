create view v_user_social_category as
  SELECT usr_soc_cat.id,
    usr_soc_cat.user_id,
    usr_soc_cat.social_category_id,
    soc_cat.category_name AS social_category_name
   FROM (user_social_category usr_soc_cat
     JOIN social_category soc_cat ON ((usr_soc_cat.social_category_id = soc_cat.id)));

