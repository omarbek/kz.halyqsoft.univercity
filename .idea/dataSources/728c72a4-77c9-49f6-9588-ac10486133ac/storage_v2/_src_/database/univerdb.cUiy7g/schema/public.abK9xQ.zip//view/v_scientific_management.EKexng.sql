create view v_scientific_management as
  SELECT scient_managem.id,
    empl_scient.employee_id,
    scient_managem.scientific_management_type_id,
    scient_managem_type.type_name AS scientific_management_type_name,
    scient_managem.students_fio,
    scient_managem.students_count,
    scient_managem.project_name,
    empl_scient.topic,
    scient_managem.result_,
    scient_managem.achievement
   FROM ((scientific_management scient_managem
     JOIN employee_scientific empl_scient ON ((scient_managem.id = empl_scient.id)))
     JOIN scientific_management_type scient_managem_type ON ((scient_managem.scientific_management_type_id = scient_managem_type.id)));

