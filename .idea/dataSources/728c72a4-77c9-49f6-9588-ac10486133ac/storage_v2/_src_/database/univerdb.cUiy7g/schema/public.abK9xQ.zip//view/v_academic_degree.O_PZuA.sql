create view v_academic_degree as
  SELECT academ_degree.id,
    academ_degree.speciality_id,
    spec.spec_name,
    academ_degree.degree_name,
    academ_degree.study_period
   FROM (academic_degree academ_degree
     JOIN speciality spec ON ((academ_degree.speciality_id = spec.id)));

