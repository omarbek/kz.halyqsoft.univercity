create view v_room_department as
  SELECT room_dept.id,
    room_dept.room_id,
    room_dept.department_id,
    dept.dept_name
   FROM (room_department room_dept
     JOIN department dept ON ((room_dept.department_id = dept.id)));

