create view v_subject_select as
  SELECT subj.id,
    subj.name_ru,
    subj.study_direct_id,
    subj.chair_id,
    subj.level_id,
    subj.subject_cycle_id,
    subj.mandatory,
    subj.creditability_id,
    cred.credit,
    contr_type.type_name AS control_type_name
   FROM ((subject subj
     JOIN creditability cred ON ((subj.creditability_id = cred.id)))
     JOIN control_type contr_type ON ((subj.control_type_id = contr_type.id)))
  WHERE ((subj.deleted = false) AND (subj.chair_id IS NOT NULL));

