create view v_curriculum_detail as
  SELECT a.id,
    a.curriculum_id,
    a.semester_id,
    b.semester_name,
    a.subject_id,
    a.code AS subject_code,
    c.name_ru AS subject_name,
        CASE
            WHEN (c.subject_cycle_id = 4) THEN a.subject_cycle_id
            ELSE c.subject_cycle_id
        END AS subject_cycle_id,
        CASE
            WHEN (c.subject_cycle_id = 4) THEN i.cycle_short_name
            ELSE d.cycle_short_name
        END AS cycle_short_name,
    c.creditability_id,
    e.credit,
    c.academic_formula_id,
    f.formula,
    a.recommended_semester,
    a.consider_credit,
    c.control_type_id,
    h.type_name AS control_type_name,
    edu_mod_type.id AS education_module_type_id,
    edu_mod_type.type_name AS education_module_type_name,
    a.deleted,
    false AS elective
   FROM ((((((((curriculum_detail a
     JOIN semester b ON ((a.semester_id = b.id)))
     JOIN subject c ON ((a.subject_id = c.id)))
     JOIN subject_cycle d ON ((c.subject_cycle_id = d.id)))
     JOIN creditability e ON ((c.creditability_id = e.id)))
     JOIN academic_formula f ON ((c.academic_formula_id = f.id)))
     JOIN control_type h ON ((c.control_type_id = h.id)))
     JOIN education_module_type edu_mod_type ON ((edu_mod_type.id = a.education_module_type_id)))
     LEFT JOIN subject_cycle i ON ((a.subject_cycle_id = i.id)));

