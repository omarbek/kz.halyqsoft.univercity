create view v_coordinator as
  SELECT empl.id,
    btrim((((((usr.last_name)::text || ' '::text) || (usr.first_name)::text) || ' '::text) || (COALESCE(usr.middle_name, ''::character varying))::text)) AS fio,
    usr.code,
    empl_dept.dept_id,
    dep.dept_name,
    empl_dept.post_id,
    post.post_name
   FROM ((((employee empl
     JOIN users usr ON ((empl.id = usr.id)))
     JOIN employee_dept empl_dept ON ((empl.id = empl_dept.employee_id)))
     JOIN department dep ON ((empl_dept.dept_id = dep.id)))
     LEFT JOIN post post ON ((empl_dept.post_id = post.id)))
  WHERE (((((empl.employee_status_id = 1) AND (usr.locked = false)) AND (length((usr.last_name)::text) > 0)) AND (empl_dept.dismiss_date IS NULL)) AND (dep.deleted = false));

