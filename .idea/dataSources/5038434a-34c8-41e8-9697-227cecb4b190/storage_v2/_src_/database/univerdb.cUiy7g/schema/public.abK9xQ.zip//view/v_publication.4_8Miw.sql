create view v_publication as
  SELECT publ.id,
    empl_scient.employee_id,
    publ.publication_type_id,
    publ_type.type_name AS publication_type_name,
    empl_scient.topic
   FROM ((publication publ
     JOIN employee_scientific empl_scient ON ((publ.id = empl_scient.id)))
     JOIN publication_type publ_type ON ((publ.publication_type_id = publ_type.id)));

